var class_taxa =
[
    [ "Taxa", "class_taxa.html#a95180249365957f7735fb4467fe2f0db", null ],
    [ "Taxa", "class_taxa.html#a8f8a07de5cd1f77fc55d66a0877a90f3", null ],
    [ "setTaxa", "class_taxa.html#a1eb527c8ea496932320c574bd41457aa", null ],
    [ "getTaxa", "class_taxa.html#a2e9bb0f35c7b515451881e347d7cada5", null ]
];