var searchData=
[
  ['data_147',['Data',['../class_data.html#af11f741cb7f587e2e495452a8905a22a',1,'Data::Data()'],['../class_data.html#a619cb123144821ee3cc9082a5e5e468d',1,'Data::Data(std::string)']]]
];
