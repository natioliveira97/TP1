var searchData=
[
  ['usuario_204',['Usuario',['../class_usuario.html#aa85a5371a098dfba5449140d9b8a472f',1,'Usuario']]]
];
