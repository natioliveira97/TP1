var searchData=
[
  ['usuario_87',['Usuario',['../class_usuario.html',1,'Usuario'],['../class_usuario.html#aa85a5371a098dfba5449140d9b8a472f',1,'Usuario::Usuario()']]],
  ['usuario_2eh_88',['Usuario.h',['../_usuario_8h.html',1,'']]]
];
