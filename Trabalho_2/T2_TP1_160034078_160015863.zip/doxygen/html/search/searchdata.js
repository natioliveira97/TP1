var indexSectionsWithContent =
{
  0: "acdeghnpstuv~",
  1: "acdehnpstuv",
  2: "acdehnpstuv",
  3: "acdeghnpstuv~",
  4: "cd"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções",
  4: "Páginas"
};

