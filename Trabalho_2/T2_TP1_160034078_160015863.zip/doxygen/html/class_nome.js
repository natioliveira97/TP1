var class_nome =
[
    [ "Nome", "class_nome.html#a500b022728cd437dd749bfe625a26a4d", null ],
    [ "Nome", "class_nome.html#a1286afeeafed7a30af95d258f02318a6", null ],
    [ "setNome", "class_nome.html#a7228b0ad762740bf7e05707b86a778af", null ],
    [ "getNome", "class_nome.html#acf79d4d5c223cf2bb3ddb2dae57ced9f", null ]
];