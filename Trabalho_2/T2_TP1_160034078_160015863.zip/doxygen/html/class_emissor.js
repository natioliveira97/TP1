var class_emissor =
[
    [ "Emissor", "class_emissor.html#a299899b4f9d89b0cfada26410c9d758b", null ],
    [ "Emissor", "class_emissor.html#a04639641eb48488d742182f021ace36c", null ],
    [ "setEmissor", "class_emissor.html#a0670f588033dde882cdaf5e2b89a69ff", null ],
    [ "getEmissor", "class_emissor.html#af620868335d4cee57456ab04d0500425", null ]
];