var class_aplicacao =
[
    [ "Aplicacao", "class_aplicacao.html#a2ea64d8a50c77fadf723205ea4104305", null ],
    [ "~Aplicacao", "class_aplicacao.html#a34aa250f6b40006cb8d5b20641fcf881", null ],
    [ "setCodigo", "class_aplicacao.html#a311f597632f532d85feb723e947020da", null ],
    [ "getCodigo", "class_aplicacao.html#ac11b4c5f303a7d7df05d5a005b7dce69", null ],
    [ "setValor", "class_aplicacao.html#ae7124294d646ac4efcd8724d0e6f7a47", null ],
    [ "getValor", "class_aplicacao.html#a149eded0891d0999ac0ada4169ec06a0", null ],
    [ "setData", "class_aplicacao.html#a5f9c7aae880c49414ed0407a55f52b12", null ],
    [ "getData", "class_aplicacao.html#aa64e5e8b6028c5bb1e0526710fa83761", null ]
];