#include "Entidades/Produto.h"

Produto::Produto()
{
    //ctor
}

Produto::~Produto()
{
    //dtor
}
