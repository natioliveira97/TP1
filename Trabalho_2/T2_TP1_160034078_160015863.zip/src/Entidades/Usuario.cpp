#include "Entidades/Usuario.h"

Usuario::Usuario(){}

Usuario::~Usuario(){}
