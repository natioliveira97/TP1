#include "Entidades/Aplicacao.h"

Aplicacao::Aplicacao(){}

Aplicacao::~Aplicacao(){}

