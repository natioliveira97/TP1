var class_horario =
[
    [ "Horario", "class_horario.html#a46801f79049e424c1a520838c33397b2", null ],
    [ "Horario", "class_horario.html#aa3afbffb68590e6b12e65fd3ee9153de", null ],
    [ "getHorario", "class_horario.html#a93d8ace6915ac2103fc4e8ac31d45867", null ],
    [ "setHorario", "class_horario.html#a2daf084639f09a871b27c76705d58a18", null ]
];