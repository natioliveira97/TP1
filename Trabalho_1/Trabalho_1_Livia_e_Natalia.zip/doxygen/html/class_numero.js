var class_numero =
[
    [ "Numero", "class_numero.html#ab065dd444840a95371b1d7fdc7fbd491", null ],
    [ "Numero", "class_numero.html#afff148d0d954689c633b98e6e0298bfc", null ],
    [ "getNumero", "class_numero.html#a44b455d621fd4d89bde0d5a442aeb1cc", null ],
    [ "setNumero", "class_numero.html#a89162510a0a9f1134f5d77b8d517ef87", null ]
];