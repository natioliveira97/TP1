var searchData=
[
  ['taxa_166',['Taxa',['../class_taxa.html#a95180249365957f7735fb4467fe2f0db',1,'Taxa::Taxa()'],['../class_taxa.html#a8f8a07de5cd1f77fc55d66a0877a90f3',1,'Taxa::Taxa(float)']]]
];
