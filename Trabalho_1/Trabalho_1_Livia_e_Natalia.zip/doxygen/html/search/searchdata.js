var indexSectionsWithContent =
{
  0: "cdeghnpstv",
  1: "cdehnpstv",
  2: "cdehnpstv",
  3: "cdeghnpstv",
  4: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Ficheiros",
  3: "Funções",
  4: "Páginas"
};

