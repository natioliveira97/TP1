var searchData=
[
  ['nome_144',['Nome',['../class_nome.html#a500b022728cd437dd749bfe625a26a4d',1,'Nome::Nome()'],['../class_nome.html#a1286afeeafed7a30af95d258f02318a6',1,'Nome::Nome(std::string)']]],
  ['numero_145',['Numero',['../class_numero.html#ab065dd444840a95371b1d7fdc7fbd491',1,'Numero::Numero()'],['../class_numero.html#afff148d0d954689c633b98e6e0298bfc',1,'Numero::Numero(std::string)']]]
];
