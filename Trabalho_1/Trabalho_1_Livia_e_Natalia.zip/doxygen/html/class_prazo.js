var class_prazo =
[
    [ "Prazo", "class_prazo.html#a224ddc6d0975f4d9585f1581069bb307", null ],
    [ "Prazo", "class_prazo.html#a18548f582ccd53882a56d3dd41226ef6", null ],
    [ "getPrazo", "class_prazo.html#a46fb711854724a89cc7775596937ec63", null ],
    [ "setPrazo", "class_prazo.html#aa3334052b8be3af3a2b63415f8b25024", null ]
];