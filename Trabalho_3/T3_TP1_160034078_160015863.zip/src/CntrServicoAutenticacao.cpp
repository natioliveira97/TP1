#include "CntrServicoAutenticacao.h"

CntrServicoAutenticacao::CntrServicoAutenticacao()
{
    //ctor
}
