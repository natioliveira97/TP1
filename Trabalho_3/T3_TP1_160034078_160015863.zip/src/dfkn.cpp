#include "dfkn.h"

dfkn::dfkn()
{
    //ctor
}

dfkn::~dfkn()
{
    //dtor
}
