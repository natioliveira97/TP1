#ifndef DFKN_H
#define DFKN_H


class dfkn
{
    public:
        dfkn();
        virtual ~dfkn();

    protected:

    private:
};

#endif // DFKN_H
